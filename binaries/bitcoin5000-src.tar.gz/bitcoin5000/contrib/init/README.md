Sample configuration files for:
```
SystemD: bitcoin5000d.service
Upstart: bitcoin5000d.conf
OpenRC:  bitcoin5000d.openrc
         bitcoin5000d.openrcconf
CentOS:  bitcoin5000d.init
OS X:    org.bitcoin5000.bitcoin5000d.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
